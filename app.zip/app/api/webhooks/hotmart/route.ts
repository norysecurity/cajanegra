import { createClient } from '@supabase/supabase-js'
import { NextResponse } from 'next/server'

// Conexão administrativa para ignorar travas e liberar o curso
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.SUPABASE_SERVICE_ROLE_KEY || ''
)

// Forçamos o Next.js a entender que esta rota é dinâmica e aceita POST
export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    console.log("JSON RECEBIDO DA HOTMART:", JSON.stringify(body, null, 2))

    // Na versão 2.0.0 que você está usando, os dados ficam dentro de 'data'
    // O email fica em data.buyer.email e o status em data.purchase.status
    const buyerEmail = body.data?.buyer?.email
    const purchaseStatus = body.data?.purchase?.status
    const hotmartProductId = body.data?.product?.id

    // Verificamos se a compra foi concluída (COMPLETED ou APPROVED)
    if (purchaseStatus === 'COMPLETED' || purchaseStatus === 'APPROVED') {
      
      // 1. Procura o usuário no seu banco pelo e-mail
      const { data: user } = await supabaseAdmin
        .from('profiles')
        .select('id')
        .eq('email', buyerEmail)
        .single()

      if (!user) {
        console.error("Usuário não encontrado para o email:", buyerEmail)
        return NextResponse.json({ error: 'Usuario nao existe' }, { status: 200 }) // Respondemos 200 para a Hotmart parar de tentar
      }

      // 2. Procura o curso pelo ID da Hotmart (no seu caso o ID 0 ou o ID do produto real)
      const { data: product } = await supabaseAdmin
        .from('products')
        .select('id')
        .eq('hotmart_id', hotmartProductId.toString())
        .single()

      if (!product) {
        console.error("Produto Hotmart nao mapeado no banco ID:", hotmartProductId)
        return NextResponse.json({ error: 'Produto nao mapeado' }, { status: 200 })
      }

      // 3. Libera o acesso na tabela de compras
      const { error: purchaseError } = await supabaseAdmin
        .from('purchases')
        .insert({
          user_id: user.id,
          product_id: product.id,
          status: 'active'
        })

      if (purchaseError) {
        console.error("Erro ao inserir compra:", purchaseError)
        return NextResponse.json({ error: 'Erro no banco' }, { status: 500 })
      }

      console.log(`✅ ACESSO LIBERADO: ${buyerEmail}`)
      return NextResponse.json({ success: true }, { status: 200 })
    }

    return NextResponse.json({ message: 'Evento ignorado' }, { status: 200 })
  } catch (err) {
    console.error("ERRO NO WEBHOOK:", err)
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 })
  }
}

// Essa função evita o erro 405 se alguém tentar acessar via navegador
export async function GET() {
  return NextResponse.json({ message: 'Use POST para este endpoint' }, { status: 405 })
}