import { streamText } from 'ai'
import { openai as vercelOpenAI } from '@ai-sdk/openai'
import OpenAI from 'openai'
import { createClient } from '@supabase/supabase-js'

export const runtime = 'nodejs' // EMBEDDINGS não rodam bem no Edge

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Pegando última mensagem (compatível AI SDK 6)
    const lastMessage =
      messages[messages.length - 1]?.content ||
      messages[messages.length - 1]?.parts?.[0]?.text ||
      ''

    // ❗ Use SERVICE ROLE só no backend Node
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    )

    // OpenAI oficial para embeddings
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })

    // 1️⃣ GERAR EMBEDDING
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: lastMessage,
    })

    const embedding = embeddingResponse.data[0].embedding

    // 2️⃣ BUSCAR CONTEXTO NO SUPABASE
    const { data: documents, error } = await supabase.rpc('match_documents', {
      query_embedding: embedding,
      match_threshold: 0.3,
      match_count: 5,
    })

    if (error) {
      console.error('Erro Supabase RPC:', error)
    }

    const context =
      documents?.map((d: any) => d.content).join('\n\n') || ''

    // 3️⃣ CHAT STREAMING (VERCEL AI SDK)
    const result = await streamText({
      model: vercelOpenAI('gpt-4.1-mini'),
      messages,
      system: `
Você é a Iara, mentora da plataforma.
Use o contexto abaixo para responder:

${context}

Responda sempre em português, claro e didático.
      `,
    })

    return result.toTextStreamResponse()

  } catch (error: any) {
    console.error('ERRO CRÍTICO CHAT:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    )
  }
}
