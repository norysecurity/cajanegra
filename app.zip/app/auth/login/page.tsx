'use client'
import { createClient } from '@/lib/supabase/client'
import { useState } from 'react'
import { Loader2, Lock } from 'lucide-react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const supabase = createClient()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin
    
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${siteUrl}/auth/callback`,
      },
    })

    if (error) {
      setMessage('Erro: ' + error.message)
    } else {
      setMessage('Link de acesso enviado para seu e-mail.')
    }
    setLoading(false)
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0a0a0a] text-white">
      {/* Efeito de fundo sutil */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-zinc-800/20 via-black to-black pointer-events-none" />

      <div className="relative z-10 w-full max-w-md p-10 space-y-8 bg-zinc-950/50 backdrop-blur-xl rounded-2xl border border-zinc-800 shadow-2xl">
        
        <div className="text-center space-y-2">
          {/* Ícone de Cadeado para dar ar de segurança */}
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-zinc-900 rounded-full border border-zinc-800">
                <Lock className="w-6 h-6 text-red-600" />
            </div>
          </div>
          
          <h1 className="text-3xl font-extrabold text-white tracking-tight">
            APP DOUGLAS
          </h1>
          <p className="text-zinc-500 text-sm">
            Digite seu e-mail para receber o acesso seguro.
          </p>
        </div>
        
        {message ? (
          <div className="p-4 bg-green-500/10 text-green-400 rounded-lg text-center border border-green-500/20 text-sm animate-in fade-in slide-in-from-bottom-2">
            {message}
          </div>
        ) : (
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <label className="text-xs font-medium text-zinc-400 uppercase tracking-wider ml-1">
                E-mail Corporativo / Pessoal
              </label>
              <input
                type="email"
                placeholder="nome@exemplo.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl text-white placeholder-zinc-600 focus:border-red-600 focus:ring-1 focus:ring-red-600 outline-none transition-all"
                required
              />
            </div>

            <button 
              disabled={loading}
              className="w-full p-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all hover:scale-[1.02] active:scale-[0.98] flex justify-center items-center gap-2 shadow-lg shadow-red-900/20"
            >
              {loading ? <Loader2 className="animate-spin w-5 h-5" /> : 'ENVIAR LINK DE ACESSO'}
            </button>
          </form>
        )}

        <div className="pt-4 text-center">
            <p className="text-xs text-zinc-700">
                Sistema protegido e monitorado. © 2026 App Douglas.
            </p>
        </div>
      </div>
    </div>
  )
}