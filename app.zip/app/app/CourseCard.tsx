'use client'

import Link from 'next/link'
import { 
  Play, Lock, CreditCard, CheckCircle2, AlertCircle 
} from 'lucide-react'
import SaveProductButton from '@/components/SaveProductButton'

export default function CourseCard({ product, purchasedIds, completedIds, savedIds }: any) {
  const isLocked = product.is_locked_by_default && !purchasedIds.includes(product.id)
  const isSaved = savedIds.includes(product.id)
  
  const firstLessonId = product.modules?.find((m: any) => m.lessons?.length > 0)?.lessons?.[0]?.id

  const allLessons = product.modules?.flatMap((m: any) => m.lessons) || []
  const totalLessons = allLessons.length
  const lessonsDone = allLessons.filter((l: any) => completedIds.includes(l.id)).length
  const progressPercent = totalLessons > 0 ? Math.round((lessonsDone / totalLessons) * 100) : 0
  const isFinished = progressPercent === 100 && totalLessons > 0

  // --- CORREÇÃO DO LINK HOTMART ---
  let checkoutUrl = product.hotmart_id || '#';

  // Verifica se o usuário colou um link ou só o código
  // Se NÃO começar com http, assumimos que é só o código e montamos o link
  if (checkoutUrl !== '#' && !checkoutUrl.startsWith('http')) {
      checkoutUrl = `https://pay.hotmart.com/${checkoutUrl}?checkoutMode=10`;
  }
  // Se já começar com http, usamos do jeito que está.
  // --------------------------------

  const targetLink = isLocked 
      ? checkoutUrl 
      : (firstLessonId ? `/app/view/${firstLessonId}` : '#')

  return (
    <div className="w-[85vw] max-w-[300px] md:w-[380px] md:max-w-none shrink-0 group relative cursor-pointer snap-center mr-4">
      
      <SaveProductButton productId={product.id} initialState={isSaved} />

      <Link 
        href={targetLink}
        target={isLocked ? "_blank" : "_self"} // Abre Hotmart em nova aba
        className={`block ${!firstLessonId && !isLocked ? 'cursor-not-allowed opacity-80' : ''}`}
        onClick={(e) => {
            if (!isLocked && !firstLessonId) {
                e.preventDefault();
                alert("Este curso ainda não possui aulas cadastradas.");
            }
        }}
      >
        <div className="relative aspect-video rounded-[20px] md:rounded-[40px] overflow-hidden border border-white/[0.03] bg-zinc-900 transition-all duration-500 group-hover:scale-[1.02] group-hover:border-white/10 shadow-xl">
          
          <img 
            src={product.image_url || "https://via.placeholder.com/500x300?text=Sem+Capa"} 
            className={`w-full h-full object-cover transition duration-700 ${isLocked ? 'grayscale opacity-20' : 'opacity-60'}`} 
            alt={product.title} 
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F10] via-[#0F0F10]/20 to-transparent" />
          
          {!isLocked && isFinished && (
            <div className="absolute top-3 right-3 md:top-4 md:right-4 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-1 md:px-3 md:py-1 rounded-full flex items-center gap-1 text-[7px] md:text-[8px] font-black uppercase tracking-widest backdrop-blur-md">
              <CheckCircle2 size={10} /> Concluído
            </div>
          )}

          <div className="absolute inset-0 p-5 md:p-8 flex flex-col justify-end">
            <h3 className="text-base md:text-2xl font-black leading-tight uppercase italic text-zinc-100 group-hover:text-rose-500 transition-colors truncate">
              {product.title}
            </h3>
            
            {!isLocked && totalLessons > 0 && (
              <div className="mt-3 w-full">
                <div className="flex justify-between items-end mb-1.5 px-0.5">
                  <span className="text-[7px] font-black uppercase text-zinc-600 tracking-widest italic">Progresso</span>
                  <span className="text-[9px] font-black text-rose-500 italic">{progressPercent}%</span>
                </div>
                <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-rose-600 transition-all duration-1000 ease-out shadow-[0_0_10px_rgba(225,29,72,0.4)]" 
                    style={{ width: `${progressPercent}%` }} 
                  />
                </div>
              </div>
            )}

            {!isLocked && totalLessons === 0 && (
                 <div className="mt-3 flex items-center gap-2 text-zinc-500 text-[9px] font-bold uppercase tracking-widest">
                    <AlertCircle size={12}/> Em Breve
                 </div>
            )}

            <div className="mt-4 flex items-center justify-between">
              {isLocked ? (
                <div className="flex items-center gap-2 bg-rose-600 text-white px-3 py-1.5 md:px-4 md:py-1.5 rounded-full text-[8px] md:text-[9px] font-black uppercase tracking-widest shadow-lg shadow-rose-600/20 hover:bg-rose-500 transition">
                  <CreditCard size={12} /> Desbloquear
                </div>
              ) : (
                <div className={`flex items-center gap-2 text-zinc-100 text-[8px] md:text-[9px] font-black uppercase tracking-widest opacity-100 md:opacity-0 group-hover:opacity-100 transition-all md:transform md:translate-y-2 md:group-hover:translate-y-0 ${!firstLessonId ? 'hidden' : ''}`}>
                  <Play size={12} fill="white" /> {progressPercent > 0 ? 'Continuar' : 'Começar'}
                </div>
              )}
              {isLocked && <Lock size={14} className="text-zinc-700" />}
            </div>
          </div>
        </div>
      </Link>
    </div>
  )
}