'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutGrid, Bookmark, User } from 'lucide-react'
import SignOutButton from '@/components/SignOutButton'

export default function Sidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => pathname === path

  return (
    <aside className="hidden md:flex fixed left-0 top-0 h-full w-20 border-r border-white/[0.03] bg-[#0F0F10] z-50 flex-col items-center py-8 gap-10">
      {/* Logo */}
      <div className="w-10 h-10 bg-rose-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(225,29,72,0.2)]">
        <span className="font-black italic text-lg text-white">D</span>
      </div>

      {/* Navegação */}
      <nav className="flex flex-col gap-8 text-zinc-600">
        <Link href="/app" title="Dashboard">
          <LayoutGrid 
            size={22} 
            className={`transition cursor-pointer ${isActive('/app') ? 'text-white' : 'hover:text-white'}`} 
          />
        </Link>
        
        <Link href="/app/saved" title="Salvos">
          <Bookmark 
            size={22} 
            className={`transition cursor-pointer ${isActive('/app/saved') ? 'text-white' : 'hover:text-white'}`} 
          />
        </Link>

        <Link href="/app/profile" title="Meu Perfil">
          <User 
            size={22} 
            className={`transition cursor-pointer ${isActive('/app/profile') ? 'text-white' : 'hover:text-white'}`} 
          />
        </Link>
      </nav>

      {/* Logout */}
      <div className="mt-auto">
        <SignOutButton />
      </div>
    </aside>
  )
}