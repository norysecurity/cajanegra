import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import ViewContentClient from './ViewContentClient'

export default async function ViewContent(props: { params: Promise<{ id: string }> }) {
  const params = await props.params
  const supabase = await createClient()
  
  // 1. LOGIN CHECK
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  // 2. BUSCA A AULA (Garantindo que buscamos o campo de conteúdo/texto)
  const { data: lesson } = await supabase
    .from('lessons')
    .select('*')
    .eq('id', params.id)
    .single()

  if (!lesson) redirect('/app')

  // 3. BUSCA MÓDULO E PRODUTO
  const { data: module } = await supabase.from('modules').select('*, products(*)').eq('id', lesson.module_id).single()

  // 4. LISTA DE AULAS (SIDEBAR)
  const { data: moduleLessons } = await supabase
    .from('lessons')
    .select('id, title, type')
    .eq('module_id', lesson.module_id)
    .order('created_at', { ascending: true })

  // 5. LISTA DE AULAS CONCLUÍDAS (PROGRESSO)
  const { data: completedData } = await supabase
    .from('user_lessons_completed')
    .select('lesson_id')
    .eq('user_id', user.id)
  const completedLessonIds = completedData?.map((c: any) => c.lesson_id) || []

  // 6. BUSCA COMENTÁRIOS + REAÇÕES
  const { data: rawComments } = await supabase
    .from('lesson_comments')
    .select(`
      *,
      profiles (email),
      comment_reactions (user_id)
    `)
    .eq('lesson_id', params.id)
    .order('created_at', { ascending: false })

  const comments = rawComments?.map((c: any) => ({
    ...c,
    is_liked_by_user: c.comment_reactions.some((r: any) => r.user_id === user.id),
    likes_count: c.comment_reactions.length
  })) || []

  // 7. INTERAÇÃO GERAL DA AULA
  const { data: interaction } = await supabase
    .from('lesson_interactions')
    .select('is_liked')
    .eq('user_id', user.id)
    .eq('lesson_id', params.id)
    .maybeSingle()
  
  const { count: totalLikes } = await supabase
    .from('lesson_interactions')
    .select('*', { count: 'exact', head: true })
    .eq('lesson_id', params.id)
    .eq('is_liked', true)

  return (
    <ViewContentClient 
      lesson={lesson} 
      moduleLessons={moduleLessons || []} 
      product={module?.products || {}}
      moduleTitle={module?.title}
      initialComments={comments}
      userId={user.id}
      completedLessonIds={completedLessonIds}
      initialInteraction={interaction}
      totalLikes={totalLikes || 0}
      lastTime={0}
      // Passamos o texto que a Iara vai ler (caso seja um PDF)
      lessonContent={lesson.content || lesson.description || ''} 
    />
  )
}