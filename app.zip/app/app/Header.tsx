'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client' // Importa o cliente navegador
import { Search, Bell, Loader2 } from 'lucide-react'
import Link from 'next/link'

export default function Header() {
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    async function loadProfile() {
      // 1. Pega o usuário logado
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // 2. Busca o perfil atualizado
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      // 3. Verifica compras (Plano)
      const { count } = await supabase
        .from('purchases')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'active')
      
      const isPremium = (count || 0) > 0
      
      setProfile({
        name: data?.full_name || user.email?.split('@')[0],
        email: user.email,
        avatar: data?.avatar_url,
        isPremium: isPremium,
        plan: isPremium ? "Membro Elite" : "Gratuito"
      })
      setLoading(false)
    }

    loadProfile()
  }, []) // Roda apenas uma vez ao carregar

  return (
    <header className="h-16 md:h-20 border-b border-white/[0.03] px-6 md:px-10 flex justify-between items-center bg-[#0F0F10]/80 backdrop-blur-md sticky top-0 z-40">
      
      {/* Barra de Pesquisa */}
      <div className="flex items-center bg-zinc-900/40 border border-white/[0.05] rounded-full px-5 py-2 w-full max-w-[200px] md:max-w-[400px] gap-3">
        <Search size={14} className="text-zinc-600" />
        <input 
          type="text" 
          placeholder="Buscar conteúdo..." 
          className="bg-transparent border-none outline-none text-xs w-full placeholder:text-zinc-700 text-zinc-300" 
        />
      </div>

      {/* Área do Usuário */}
      <div className="flex items-center gap-4">
         <button className="text-zinc-600 hover:text-white transition relative">
            <Bell size={18} />
            <span className="absolute top-0 right-0 w-1.5 h-1.5 bg-rose-600 rounded-full" />
         </button>

         <div className="w-px h-8 bg-white/5 hidden sm:block" />

         <Link href="/app/profile" className="flex items-center gap-3 group">
             {loading ? (
                <div className="flex items-center gap-2 animate-pulse">
                   <div className="h-8 w-20 bg-zinc-800 rounded"></div>
                   <div className="h-9 w-9 bg-zinc-800 rounded-full"></div>
                </div>
             ) : (
               <>
                 <div className="text-right hidden sm:block">
                    <p className="text-[11px] font-bold text-zinc-200 capitalize leading-none group-hover:text-white transition">
                      {profile?.name}
                    </p>
                    <p className={`text-[9px] font-black mt-1 uppercase tracking-tighter ${profile?.isPremium ? 'text-rose-500' : 'text-zinc-500'}`}>
                      {profile?.plan}
                    </p>
                 </div>
                 
                 <div className="w-9 h-9 rounded-full bg-zinc-800 border border-white/5 flex items-center justify-center overflow-hidden ring-2 ring-transparent group-hover:ring-white/10 transition">
                    {profile?.avatar ? (
                      // Adiciona timestamp para forçar atualização da imagem
                      <img src={`${profile.avatar}?t=${new Date().getTime()}`} className="w-full h-full object-cover" />
                    ) : (
                      <span className="font-bold text-zinc-500 text-xs">
                        {profile?.name?.[0]?.toUpperCase()}
                      </span>
                    )}
                 </div>
               </>
             )}
         </Link>
      </div>
    </header>
  )
}