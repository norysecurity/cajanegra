'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Play, Lock, ChevronRight } from 'lucide-react'
import CheckoutModal from '@/components/CheckoutModal'

export default function DashboardClient({ products }: { products: any[] }) {
  const [selectedProduct, setSelectedProduct] = useState<any>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleProductClick = (product: any) => {
    if (product.isLocked) {
      setSelectedProduct(product)
      setIsModalOpen(true)
    }
  }

  return (
    <div className="space-y-8 pb-10">
      <CheckoutModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        productTitle={selectedProduct?.title || ""}
        price={selectedProduct?.price || "R$ 47,00"}
      />

      <section className="pl-6">
        <div className="flex items-center gap-2 mb-4 border-l-4 border-red-600 pl-3">
          <h3 className="text-lg font-bold text-white uppercase tracking-tight">Meus Treinamentos</h3>
          <ChevronRight size={16} className="text-zinc-600" />
        </div>
        
        <div className="flex overflow-x-auto gap-4 pr-6 pb-4 scrollbar-hide snap-x">
            {products.map((product) => (
              <div key={product.id} className="relative flex-none snap-center group w-[260px] aspect-video">
                {product.isLocked ? (
                  <div 
                    onClick={() => handleProductClick(product)}
                    className="cursor-pointer w-full h-full rounded-xl overflow-hidden border border-red-900/40 bg-zinc-900 relative active:scale-95 transition-all duration-300 shadow-lg"
                  >
                    <div className="absolute inset-0 bg-black/60 z-10 flex items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-black/60 border border-red-500/30 flex items-center justify-center backdrop-blur-sm shadow-xl">
                        <Lock className="text-red-500 w-5 h-5" />
                      </div>
                    </div>
                    {product.image && <img src={product.image} className="w-full h-full object-cover opacity-30 grayscale" />}
                  </div>
                ) : (
                  <Link 
                    href={product.link}
                    className="block w-full h-full rounded-xl overflow-hidden border border-white/5 bg-zinc-900 relative active:scale-95 transition-all duration-300 shadow-lg"
                  >
                    <div className="absolute inset-0 flex items-center justify-center z-10">
                      <div className="w-12 h-12 rounded-full bg-white/10 border border-white/40 flex items-center justify-center backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100">
                        <Play className="text-white w-5 h-5 fill-white" />
                      </div>
                    </div>
                    {product.image && <img src={product.image} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-110 transition duration-500" />}
                  </Link>
                )}

                <div className="mt-3 px-1">
                  <h4 className={`text-sm font-bold leading-tight line-clamp-2 ${product.isLocked ? 'text-zinc-500' : 'text-zinc-100'}`}>
                    {product.title}
                  </h4>
                  {product.isLocked && <span className="text-[10px] text-red-500 font-bold uppercase mt-1 block tracking-widest">Premium</span>}
                </div>
              </div>
            ))}
        </div>
      </section>
    </div>
  )
}