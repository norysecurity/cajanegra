import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { Video, FileText } from 'lucide-react'
import Carousel from './Carousel'
import CourseCard from './CourseCard'

export const dynamic = 'force-dynamic'

export default async function Dashboard() {
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  const { data: products } = await supabase
    .from('products')
    .select('*, modules(*, lessons(*))')
    .order('created_at', { ascending: true })

  const { data: purchases } = await supabase
    .from('purchases')
    .select('product_id')
    .eq('user_id', user.id)
    .eq('status', 'active')

  const { data: completedLessons } = await supabase
    .from('user_lessons_completed')
    .select('lesson_id')
    .eq('user_id', user.id)

  const { data: savedProducts } = await supabase
    .from('user_saved_products')
    .select('product_id')
    .eq('user_id', user.id)

  const purchasedIds = purchases?.map(p => p.product_id) || []
  const completedIds = completedLessons?.map(c => c.lesson_id) || []
  const savedIds = savedProducts?.map(s => s.product_id) || []

  const videoCourses = products?.filter(p => p.modules?.[0]?.lessons?.[0]?.type !== 'script') || []
  const scriptCourses = products?.filter(p => p.modules?.[0]?.lessons?.[0]?.type === 'script') || []

  return (
    <div className="bg-[#0F0F10] text-zinc-200 font-sans min-h-full">
      
      {/* HERO BANNER - MANTIDO E AJUSTADO */}
      <section className="px-4 md:px-10 py-6 md:py-10">
        <div className="relative w-full min-h-[50vh] md:min-h-0 md:aspect-[21/9] md:max-h-[400px] rounded-[32px] md:rounded-[48px] overflow-hidden border border-white/[0.03] bg-zinc-900 shadow-2xl flex flex-col justify-end md:block">
          <img 
            src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=2070" 
            className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale mix-blend-overlay" 
            alt="Hero" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F10] via-[#0F0F10]/60 to-transparent md:bg-gradient-to-r" />
          
          <div className="relative z-10 p-6 md:p-16 h-full flex flex-col justify-end md:justify-center max-w-2xl gap-3 md:gap-6 pb-8">
             <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-3 py-1 w-fit backdrop-blur-md mb-2">
               <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
               <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-300">Nova Plataforma</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-black tracking-tighter leading-[0.9] uppercase italic text-zinc-100">
              Domine a <br/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 to-rose-700">Execução.</span>
            </h1>
          </div>
        </div>
      </section>

      {/* CARROSSEL DE TREINAMENTOS */}
      <section className="pl-4 md:pl-10 pb-8">
        <h2 className="text-sm md:text-lg font-black tracking-widest uppercase italic mb-4 md:mb-6 flex items-center gap-2 text-zinc-400">
          <Video className="text-rose-600" size={18} /> Treinamentos
        </h2>
        {/* O Carrossel agora cuida do scroll */}
        <Carousel>
          {videoCourses.map((product) => (
            <CourseCard 
              key={product.id} 
              product={product} 
              purchasedIds={purchasedIds} 
              completedIds={completedIds} 
              savedIds={savedIds} 
            />
          ))}
        </Carousel>
      </section>

      {/* CARROSSEL DE BIBLIOTECA */}
      <section className="pl-4 md:pl-10 pb-20">
        <h2 className="text-sm md:text-lg font-black tracking-widest uppercase italic mb-4 md:mb-6 flex items-center gap-2 text-zinc-400">
          <FileText className="text-blue-500" size={18} /> Biblioteca
        </h2>
        <Carousel>
          {scriptCourses.map((product) => (
            <CourseCard 
              key={product.id} 
              product={product} 
              purchasedIds={purchasedIds} 
              completedIds={completedIds} 
              savedIds={savedIds} 
            />
          ))}
        </Carousel>
      </section>
    </div>
  )
}