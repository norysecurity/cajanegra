import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { ChevronLeft, Camera, Shield, Zap, Mail, User, Save } from 'lucide-react'
import ProfileForm from './ProfileForm' // Vamos criar esse componente abaixo

export default async function ProfilePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  // 1. Busca dados do perfil
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()

  // 2. Verifica se tem compras (Plano)
  const { count } = await supabase
    .from('purchases')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', user.id)
    .eq('status', 'active')

  const isPremium = (count || 0) > 0
  const planName = isPremium ? "Membro Elite" : "Plano Gratuito"

  return (
    <div className="min-h-screen bg-[#0F0F10] text-zinc-100 p-6 md:p-10 md:pl-28 flex justify-center items-center">
      
      <div className="w-full max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/app" className="p-2 bg-zinc-900 rounded-full hover:bg-white hover:text-black transition">
            <ChevronLeft size={20} />
          </Link>
          <h1 className="text-2xl font-black uppercase italic tracking-tighter">Meu Perfil</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* COLUNA ESQUERDA: CARTÃO DO PLANO */}
          <div className="space-y-6">
             <div className={`p-6 rounded-[32px] border ${isPremium ? 'bg-gradient-to-br from-zinc-900 to-black border-rose-500/50 shadow-[0_0_30px_rgba(225,29,72,0.15)]' : 'bg-zinc-900 border-white/5'}`}>
                <div className="flex justify-between items-start mb-4">
                   <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isPremium ? 'bg-rose-600 text-white' : 'bg-zinc-800 text-zinc-500'}`}>
                      <Zap size={24} fill={isPremium ? "currentColor" : "none"} />
                   </div>
                   {isPremium && <span className="bg-rose-500/10 text-rose-500 text-[9px] font-black uppercase px-2 py-1 rounded-full border border-rose-500/20">Ativo</span>}
                </div>
                <h3 className="text-zinc-500 text-xs font-bold uppercase tracking-widest mb-1">Seu Plano Atual</h3>
                <h2 className="text-2xl font-black italic uppercase text-white">{planName}</h2>
                <p className="text-xs text-zinc-500 mt-2 leading-relaxed">
                  {isPremium 
                    ? "Você tem acesso total a todos os treinamentos e materiais exclusivos." 
                    : "Faça o upgrade para desbloquear todo o potencial da plataforma."}
                </p>
             </div>

             <div className="p-6 rounded-[32px] bg-zinc-900/50 border border-white/5 space-y-4">
                <div className="flex items-center gap-3">
                   <Shield size={16} className="text-emerald-500" />
                   <div>
                      <p className="text-xs font-bold text-white">Conta Verificada</p>
                      <p className="text-[10px] text-zinc-500">Acesso seguro SSL</p>
                   </div>
                </div>
                <div className="flex items-center gap-3">
                   <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                   <div>
                      <p className="text-xs font-bold text-white">Status do Sistema</p>
                      <p className="text-[10px] text-zinc-500">Todos os serviços online</p>
                   </div>
                </div>
             </div>
          </div>

          {/* COLUNA DIREITA: FORMULÁRIO DE EDIÇÃO */}
          <div className="md:col-span-2">
             <div className="bg-[#09090A] border border-white/5 rounded-[32px] p-8">
                <ProfileForm user={user} profile={profile} />
             </div>
          </div>

        </div>
      </div>
    </div>
  )
}