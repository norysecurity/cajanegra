'use client'

import { useState } from 'react'
import { Camera, Mail, User, Save, Loader2 } from 'lucide-react'
import { updateProfile } from '@/app/admin/actions'

export default function ProfileForm({ user, profile }: any) {
  const [loading, setLoading] = useState(false)
  const [preview, setPreview] = useState(profile?.avatar_url || null)

  const handleImageChange = (e: any) => {
    const file = e.target.files[0]
    if (file) {
      const objectUrl = URL.createObjectURL(file)
      setPreview(objectUrl)
    }
  }

  const handleSubmit = async (formData: FormData) => {
    setLoading(true)
    await updateProfile(formData)
    setLoading(false)
    alert("Perfil atualizado com sucesso!")
  }

  return (
    <form action={handleSubmit} className="space-y-8">
      
      {/* SEÇÃO DE FOTO */}
      <div className="flex flex-col items-center gap-4 pb-8 border-b border-white/5">
         <div className="relative group cursor-pointer">
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-zinc-900 ring-1 ring-white/10 relative bg-zinc-800">
               {preview ? (
                 <img src={preview} className="w-full h-full object-cover" alt="Avatar" />
               ) : (
                 <div className="w-full h-full flex items-center justify-center text-zinc-500 font-bold text-2xl">
                    {user.email[0].toUpperCase()}
                 </div>
               )}
            </div>
            {/* Overlay de Edição */}
            <div className="absolute inset-0 rounded-full bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300">
               <Camera size={24} className="text-white" />
            </div>
            {/* Input Invisível */}
            <input 
              type="file" 
              name="avatar" 
              accept="image/*" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleImageChange} 
            />
            <input type="hidden" name="current_avatar_url" value={profile?.avatar_url || ''} />
         </div>
         <p className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest">Toque para alterar</p>
      </div>

      {/* CAMPOS DE TEXTO */}
      <div className="space-y-5">
         <div className="space-y-1.5">
            <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest flex items-center gap-2">
               <Mail size={12} /> E-mail (Não alterável)
            </label>
            <input 
               disabled 
               value={user.email} 
               className="w-full bg-zinc-900/50 border border-white/5 rounded-2xl px-5 py-4 text-xs text-zinc-400 outline-none cursor-not-allowed" 
            />
         </div>

         <div className="space-y-1.5">
            <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest flex items-center gap-2">
               <User size={12} /> Nome Completo
            </label>
            <input 
               name="full_name"
               defaultValue={profile?.full_name || ''}
               placeholder="Como você quer ser chamado?"
               className="w-full bg-black border border-white/10 rounded-2xl px-5 py-4 text-xs text-white outline-none focus:border-rose-500/50 transition focus:bg-zinc-900" 
            />
         </div>
      </div>

      <div className="pt-4">
         <button 
           type="submit" 
           disabled={loading}
           className="w-full bg-white hover:bg-rose-600 text-black hover:text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-xl hover:shadow-rose-600/20"
         >
           {loading ? <Loader2 size={16} className="animate-spin" /> : <><Save size={16} /> Salvar Alterações</>}
         </button>
      </div>

    </form>
  )
}