import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Sidebar from './Sidebar' 
import Header from './Header'
import AnalyticsTracker from '@/components/AnalyticsTracker'
import MobileMenu from '@/components/MobileMenu' 
import IaraChat from '@/components/IaraChat' // <--- 1. IMPORTAÇÃO DA IARA

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/auth/login')

  return (
    <div className="min-h-screen bg-[#0F0F10] text-zinc-100 font-sans flex flex-col md:flex-row relative">
      
      <AnalyticsTracker />

      {/* --- SIDEBAR (SÓ NO COMPUTADOR) --- */}
      <div className="hidden md:block w-64 shrink-0 z-50">
         <Sidebar /> 
      </div>

      {/* --- ÁREA PRINCIPAL --- */}
      <div className="flex-1 flex flex-col min-h-screen relative md:pl-0"> 
        <Header /> 
        
        {/* Conteúdo Principal */}
        <main className="flex-1 overflow-y-auto custom-scrollbar pb-24 md:pb-0">
          {children}
        </main>

        {/* Menu Mobile */}
        <MobileMenu />
      </div>

      {/* --- IARA AI (FLUTUANTE) --- */}
      {/* Como ela tem position:fixed, pode ficar aqui no final sem quebrar o layout */}
      <IaraChat />

    </div>
  )
}