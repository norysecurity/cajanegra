import { MetadataRoute } from 'next'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Nome do Seu Projeto',
    short_name: 'Projeto',
    description: 'Sua plataforma de cursos exclusiva',
    start_url: '/app', // Quando abrir o app, vai direto pro dashboard
    display: 'standalone', // <--- ISSO TIRA A BARRA DO NAVEGADOR
    background_color: '#000000',
    theme_color: '#000000',
    icons: [
      {
        src: '/icon-192.png',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: '/icon-512.png',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}