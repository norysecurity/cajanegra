import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css"; 
import InstallPWA from "@/components/InstallPWA"; // <--- ATUALIZADO: Importamos o componente do Botão

const inter = Inter({ subsets: ["latin"] });

// Configuração para Celular (Tela Cheia e Cores)
export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false, // Impede zoom com pinça (sensação nativa)
}

export const metadata: Metadata = {
  title: "App Douglas",
  description: "Streaming Premium",
  // Se você criou o app/manifest.ts, o Next.js gera isso automático, 
  // mas deixar explícito ajuda alguns navegadores antigos.
  manifest: "/manifest.webmanifest", 
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Douglas TV",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>
        {/* O Botão de Instalar flutuante fica aqui */}
        <InstallPWA />
        
        {children}
      </body>
    </html>
  );
}