'use client'

import { useState } from 'react'
import { updateContent } from './actions'
import { X, Save, Loader2, Video, FileText, Link as LinkIcon, AlignLeft } from 'lucide-react'

export default function EditorModal({ item, type, onClose }: any) {
  const [loading, setLoading] = useState(false)
  // Se o tipo for indefinido, assume video. Se for script, mantem script.
  const [lessonType, setLessonType] = useState(item.type || 'video')

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setLoading(true)
    const formData = new FormData(event.currentTarget)
    
    try {
      await updateContent(formData)
      onClose()
    } catch (err) {
      alert("Erro ao salvar: " + err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#161618] border border-white/5 w-full max-w-lg rounded-[32px] overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
        
        <div className="px-8 py-6 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 mb-1">Painel Admin</p>
            <h2 className="text-xl font-bold text-white tracking-tight italic uppercase">
              Editar {type === 'product' ? 'Curso' : 'Conteúdo'}
            </h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-zinc-500 transition">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-5">
          <input type="hidden" name="id" value={item.id} />
          <input type="hidden" name="type" value={type} />
          
          <div className="space-y-1.5">
            <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest">Título</label>
            <input name="title" defaultValue={item.title} className="w-full bg-black/40 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white outline-none focus:border-rose-600/50 transition" required />
          </div>

          {type === 'product' ? (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest">ID Hotmart</label>
                <input name="hotmart_id" defaultValue={item.hotmart_id} className="w-full bg-black/40 border border-white/10 rounded-2xl px-4 py-3 text-xs outline-none focus:border-rose-600/50 transition" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest">URL da Capa</label>
                <input name="image_url" defaultValue={item.image_url} className="w-full bg-black/40 border border-white/10 rounded-2xl px-4 py-3 text-xs outline-none focus:border-rose-600/50 transition" />
              </div>
            </div>
          ) : (
            /* --- SELEÇÃO DE TIPO CORRIGIDA --- */
            <>
              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest text-rose-500">Tipo de Conteúdo</label>
                <select 
                  name="lesson_type" 
                  value={lessonType}
                  onChange={(e) => setLessonType(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-white/10 rounded-2xl px-4 py-3 text-xs text-white outline-none appearance-none focus:border-rose-600/50 cursor-pointer"
                >
                  <option value="video">🎥 Vídeo (YouTube)</option>
                  <option value="pdf">📚 Arquivo PDF (Google Drive)</option>
                  <option value="script">📜 Apenas Texto / Aviso</option>
                </select>
              </div>

              {/* CAMPO DE LINK DINÂMICO */}
              {lessonType !== 'script' && (
                <div className="space-y-1.5 animate-in fade-in slide-in-from-top-1">
                  <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest">
                      {lessonType === 'pdf' ? 'Link do Google Drive' : 'Link do Vídeo YouTube'}
                  </label>
                  <div className="relative">
                    {lessonType === 'pdf' ? <LinkIcon size={14} className="absolute left-4 top-3 text-zinc-500"/> : <Video size={14} className="absolute left-4 top-3 text-zinc-500"/>}
                    
                    <input 
                      name="video_url" 
                      defaultValue={item.video_url} 
                      placeholder={lessonType === 'pdf' ? "Cole o link de compartilhamento..." : "https://youtube.com/..."}
                      className="w-full bg-black/40 border border-white/10 rounded-2xl pl-10 pr-4 py-3 text-xs text-white outline-none focus:border-rose-600/50 transition" 
                    />
                  </div>
                  {lessonType === 'pdf' && (
                      <p className="text-[9px] text-zinc-600 ml-2 mt-1">* O arquivo no Drive deve estar como "Qualquer pessoa com o link".</p>
                  )}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-[9px] font-black uppercase text-zinc-500 ml-1 tracking-widest">Descrição / Conteúdo</label>
                <textarea 
                  name="content" 
                  defaultValue={item.content} 
                  rows={4} 
                  className="w-full bg-black/40 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white outline-none focus:border-rose-600/50 transition resize-none" 
                />
              </div>
            </>
          )}

          <div className="pt-4 flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 px-6 py-3 rounded-2xl text-[10px] font-black uppercase text-zinc-500 bg-white/5 hover:bg-white/10 transition">Cancelar</button>
            <button type="submit" disabled={loading} className="flex-[2] bg-white hover:bg-rose-600 text-black hover:text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase transition-all flex items-center justify-center gap-2 shadow-xl shadow-rose-600/10">
              {loading ? <Loader2 size={16} className="animate-spin" /> : <><Save size={14} /> Salvar</>}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}