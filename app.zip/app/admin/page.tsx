import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { 
  LayoutGrid, Users, BarChart3, Settings, 
  Zap, ArrowUpRight, PlayCircle, Clock, ThumbsUp, MessageSquare 
} from 'lucide-react'
import SignOutButton from '@/components/SignOutButton'
import AdminClient from './AdminClient'

export default async function AdminDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/auth/login')

  // 1. Busca de Dados Gerais
  const { count: totalUsers } = await supabase.from('profiles').select('*', { count: 'exact', head: true })
  const { data: products } = await supabase.from('products').select('*, modules(*, lessons(*))').order('created_at', { ascending: false })
  
  // 2. Busca de Dados para o BI (Monitoramento de Alunos)
  const { data: studentsStats } = await supabase
    .from('profiles')
    .select(`
      email,
      last_sign_in_at,
      user_activity_logs (seconds_watched),
      lesson_interactions (is_liked),
      lesson_comments (id)
    `)
    .limit(10)

  const userName = user.user_metadata?.full_name || user.email?.split('@')[0]

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-zinc-100 font-sans h-screen overflow-hidden">
      
      {/* SIDEBAR STARTUP STYLE */}
      <aside className="fixed left-0 top-0 h-full w-20 border-r border-white/[0.05] bg-[#0A0A0B] z-50 flex flex-col items-center py-8 gap-10">
        <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(220,38,38,0.3)]">
          <span className="font-black italic text-lg text-white">D</span>
        </div>
        <nav className="flex flex-col gap-8 text-zinc-600">
          <Link href="/admin"><LayoutGrid size={22} className="text-white cursor-pointer" /></Link>
          <Link href="/admin/users"><Users size={22} className="hover:text-white transition" /></Link>
          <Link href="/admin/monitoring"><BarChart3 size={22} className="hover:text-white transition" /></Link>
        </nav>
        <div className="mt-auto"><SignOutButton /></div>
      </aside>

      <main className="pl-20 h-full flex flex-col">
        {/* NAVBAR */}
        <header className="h-20 border-b border-white/[0.05] px-10 flex justify-between items-center bg-[#0A0A0B]/80 backdrop-blur-md sticky top-0 z-40">
          <h2 className="text-[10px] font-black uppercase text-red-600 tracking-[0.3em] italic">Command Center v3.0</h2>
          <div className="flex items-center gap-4 border-l border-white/10 pl-6">
            <div className="text-right mr-4">
              <p className="text-xs font-bold text-white capitalize leading-none">{userName}</p>
              <p className="text-[9px] text-green-500 font-black mt-1 uppercase">Root Admin</p>
            </div>
          </div>
        </header>

        {/* ÁREA DE CONTEÚDO COM SCROLL INTERNO */}
        <div className="flex-1 overflow-y-auto p-10 space-y-12 custom-scrollbar">
          
          {/* STAT CARDS SUPERIORES */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard title="Total Alunos" value={totalUsers || 0} trend="+12%" />
            <StatCard title="Aulas Curtidas" value="1.420" trend="BI" />
            <div className="p-8 rounded-[40px] bg-zinc-900/40 border border-white/5 flex flex-col justify-center">
              <p className="text-zinc-500 text-[10px] font-black uppercase mb-2 italic">Performance</p>
              <h3 className="text-xl font-black text-white italic">RETENÇÃO 84%</h3>
            </div>
            <div className="p-8 rounded-[40px] bg-red-600 flex flex-col justify-center shadow-xl shadow-red-600/20">
              <p className="text-red-100 text-[10px] font-black uppercase mb-2 italic">Status</p>
              <h3 className="text-xl font-black text-white italic text-center">ONLINE</h3>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
            
            {/* COLUNA: GESTÃO DE CURSOS (EDIÇÃO E EXCLUSÃO) */}
            <div className="xl:col-span-2 space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-black uppercase text-zinc-500 flex items-center gap-3 italic tracking-widest">
                  <PlayCircle size={18} className="text-red-600" /> Grade de Conteúdos
                </h3>
              </div>
              {/* O AdminClient agora lida com o scroll interno das listas */}
              <AdminClient products={products || []} />
            </div>

            {/* COLUNA: BI DE MONITORAMENTO EM TEMPO REAL */}
            <div className="space-y-6">
               <h3 className="text-sm font-black uppercase text-zinc-500 flex items-center gap-3 italic tracking-widest">
                <BarChart3 size={18} className="text-red-600" /> Monitoramento (BI)
              </h3>
              
              <div className="bg-zinc-900/30 border border-white/[0.05] rounded-[48px] p-8 space-y-6 backdrop-blur-sm">
                <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest border-b border-white/5 pb-4">Atividade Recente</p>
                
                {studentsStats?.map((student: any) => {
                  const totalMinutes = Math.floor((student.user_activity_logs?.reduce((acc: any, curr: any) => acc + curr.seconds_watched, 0) || 0) / 60)
                  const likes = student.lesson_interactions?.filter((i: any) => i.is_liked).length || 0

                  return (
                    <div key={student.email} className="flex flex-col gap-2 p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:bg-white/[0.05] transition group">
                      <div className="flex justify-between items-start">
                        <div className="max-w-[150px]">
                          <p className="text-xs font-bold text-zinc-200 truncate">{student.email}</p>
                          <p className="text-[9px] text-zinc-500 font-bold uppercase mt-1 flex items-center gap-1">
                            <Clock size={10} className="text-red-600" /> {totalMinutes}m na plataforma
                          </p>
                        </div>
                        <div className="flex gap-3 text-zinc-600">
                          <div className="flex items-center gap-1 group-hover:text-green-500 transition">
                            <ThumbsUp size={12} /> <span className="text-[10px] font-black">{likes}</span>
                          </div>
                          <div className="flex items-center gap-1 group-hover:text-blue-500 transition">
                            <MessageSquare size={12} /> <span className="text-[10px] font-black">{student.lesson_comments?.length || 0}</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* BARRA DE PROGRESSO VISUAL SIMULADA */}
                      <div className="w-full h-1 bg-zinc-800 rounded-full mt-1 overflow-hidden">
                        <div className="h-full bg-red-600" style={{ width: `${Math.min(totalMinutes * 2, 100)}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* CARD DE INSIGHT */}
              <div className="p-8 rounded-[40px] bg-gradient-to-br from-zinc-900 to-black border border-white/5">
                <Zap size={20} className="text-yellow-500 mb-4" />
                <p className="text-xs font-bold text-zinc-200 uppercase tracking-tighter">Insight de IA</p>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed">
                  O módulo "Script de Vendas" possui 40% mais comentários que a média. Considere criar um conteúdo complementar.
                </p>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  )
}

function StatCard({ title, value, trend }: any) {
  return (
    <div className="p-8 rounded-[32px] bg-zinc-900/20 border border-white/[0.05] group hover:border-white/10 transition duration-500">
      <p className="text-[10px] font-black uppercase text-zinc-500 mb-4 tracking-widest">{title}</p>
      <div className="flex items-end gap-3">
        <h3 className="text-4xl font-black italic leading-none group-hover:text-red-500 transition-colors">{value}</h3>
        <span className="text-green-500 text-[10px] font-black mb-1">{trend}</span>
      </div>
    </div>
  )
}