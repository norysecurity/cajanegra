import { createClient } from '@/lib/supabase/server'
import { Users, Mail, Calendar, CheckCircle, Ban } from 'lucide-react'

export default async function StudentsManager() {
  const supabase = await createClient()
  const { data: students } = await supabase.from('profiles').select('*, purchases(*, products(title))')

  return (
    <div className="min-h-screen bg-[#0A0A0B] p-10 pl-24 text-white">
      <header className="mb-12">
        <h1 className="text-4xl font-black uppercase italic tracking-tighter">Gestão de <span className="text-zinc-600">Alunos</span></h1>
        <p className="text-zinc-500 mt-2 font-medium">Monitore acessos e gerencie permissões manualmente.</p>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {students?.map((student) => (
          <div key={student.id} className="bg-zinc-900/40 border border-white/5 p-6 rounded-[30px] flex items-center justify-between hover:bg-zinc-900/60 transition group">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-zinc-800 rounded-2xl flex items-center justify-center font-black text-xl text-zinc-500 border border-white/5 uppercase">
                {student.email[0]}
              </div>
              <div>
                <h3 className="font-bold text-lg flex items-center gap-2">
                  {student.email} 
                  <CheckCircle size={14} className="text-green-500" />
                </h3>
                <div className="flex gap-4 mt-1">
                   <span className="text-[10px] font-black uppercase text-zinc-500 tracking-widest flex items-center gap-1"><Mail size={10}/> {student.full_name || 'Sem Nome'}</span>
                   <span className="text-[10px] font-black uppercase text-red-500 tracking-widest flex items-center gap-1"><Calendar size={10}/> Inscrito em {new Date(student.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-8">
               <div className="text-right">
                  <p className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">Produtos Ativos</p>
                  <p className="text-xs font-bold text-zinc-400">{student.purchases?.length || 0} cursos liberados</p>
               </div>
               <button className="p-4 bg-zinc-800 rounded-2xl text-zinc-500 hover:bg-red-600 hover:text-white transition shadow-lg">
                  <Ban size={20} />
               </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}