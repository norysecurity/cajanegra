'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

// Função auxiliar para links do YouTube
function formatYoutubeUrl(url: string) {
  if (!url) return '';
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? `https://www.youtube.com/embed/${match[2]}` : url;
}

// --- GESTÃO DE PRODUTOS (ADMIN) ---

export async function createProduct(title: string) {
  const supabase = await createClient()
  await supabase.from('products').insert({ title, image_url: '', is_locked_by_default: true })
  revalidatePath('/admin'); revalidatePath('/app')
}

export async function deleteProduct(id: string) {
  const supabase = await createClient()
  await supabase.from('products').delete().eq('id', id)
  revalidatePath('/admin'); revalidatePath('/app')
}

export async function toggleProductLock(id: string, currentStatus: boolean) {
  const supabase = await createClient()
  await supabase.from('products').update({ is_locked_by_default: !currentStatus }).eq('id', id)
  revalidatePath('/admin'); revalidatePath('/app')
}

// --- GESTÃO DE MÓDULOS E AULAS (ADMIN) ---

export async function addModule(productId: string, title: string) {
  const supabase = await createClient()
  await supabase.from('modules').insert({ product_id: productId, title })
  revalidatePath('/admin')
}

export async function deleteModule(id: string) {
  const supabase = await createClient()
  await supabase.from('modules').delete().eq('id', id)
  revalidatePath('/admin')
}

export async function addLesson(moduleId: string, title: string, type: string) {
  const supabase = await createClient()
  await supabase.from('lessons').insert({ module_id: moduleId, title, type })
  revalidatePath('/admin')
}

export async function deleteLesson(id: string) {
  const supabase = await createClient()
  await supabase.from('lessons').delete().eq('id', id)
  revalidatePath('/admin')
}

export async function updateContent(formData: FormData) {
  const supabase = await createClient()
  const id = formData.get('id') as string
  const type = formData.get('type') as string // 'product' ou 'lesson' vindo do modal
  const title = formData.get('title') as string

  if (type === 'product') {
    await supabase.from('products').update({ 
      title, 
      image_url: formData.get('image_url'), 
      hotmart_id: formData.get('hotmart_id') 
    }).eq('id', id)
  } else {
    // --- LÓGICA CORRIGIDA PARA PDF VS VÍDEO ---
    const lessonType = formData.get('lesson_type') as string // 'video', 'pdf' ou 'script'
    let finalUrl = formData.get('video_url') as string

    // Só formata link do YouTube se for tipo Vídeo
    if (lessonType === 'video') {
       finalUrl = formatYoutubeUrl(finalUrl)
    }
    // Se for PDF, salva o link do Drive cru (o front-end converte pra /preview)

    await supabase.from('lessons').update({ 
      title, 
      video_url: finalUrl, 
      content: formData.get('content'), 
      type: lessonType // Salva o novo tipo no banco
    }).eq('id', id)
  }

  revalidatePath('/admin')
  revalidatePath('/app')
}

// ALIASES PARA FIX DE COMPILAÇÃO DO EDITMODAL
export const updateProduct = updateContent;
export const updateLesson = updateContent;

// --- MONITORAMENTO E INTERAÇÕES (ALUNO) ---

export async function toggleLike(lessonId: string, isLiked: boolean) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return
  await supabase.from('lesson_interactions').upsert({ user_id: user.id, lesson_id: lessonId, is_liked: isLiked })
  revalidatePath(`/app/view/${lessonId}`)
}

export async function toggleCommentLike(commentId: string, lessonId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  // 1. Verifica se já existe
  const { data: existing } = await supabase
    .from('comment_reactions')
    .select('*')
    .eq('user_id', user.id)
    .eq('comment_id', commentId)
    .single()

  if (existing) {
    // 2. Se existe, deleta (Descurtir)
    await supabase.from('comment_reactions').delete().eq('user_id', user.id).eq('comment_id', commentId)
  } else {
    // 3. Se não existe, cria (Curtir)
    await supabase.from('comment_reactions').insert({ user_id: user.id, comment_id: commentId, reaction_type: 'heart' })
  }
  
  revalidatePath(`/app/view/${lessonId}`)
}

export async function postComment(lessonId: string, content: string, parentId: string | null = null) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  const { error } = await supabase.from('lesson_comments').insert({ 
    user_id: user.id, 
    lesson_id: lessonId, 
    content, 
    parent_id: parentId 
  })

  if (error) console.error("Erro ao salvar comentário:", error.message)
  
  revalidatePath(`/app/view/${lessonId}`)
}

export async function deleteComment(commentId: string, lessonId: string) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return
  await supabase.from('lesson_comments').delete().eq('id', commentId).eq('user_id', user.id)
  revalidatePath(`/app/view/${lessonId}`)
}

// --- GESTÃO DE PROGRESSO ---

export async function toggleLessonCompletion(lessonId: string, completed: boolean) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  if (completed) {
    await supabase.from('user_lessons_completed').upsert({ user_id: user.id, lesson_id: lessonId })
  } else {
    await supabase.from('user_lessons_completed').delete().eq('user_id', user.id).eq('lesson_id', lessonId)
  }
  
  revalidatePath('/app')
  revalidatePath(`/app/view/${lessonId}`)
}

export async function saveVideoTime(lessonId: string, time: number) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return
  await supabase.from('user_video_progress').upsert({ 
    user_id: user.id, 
    lesson_id: lessonId, 
    last_time: Math.floor(time) 
  }, { onConflict: 'user_id,lesson_id' })
}

export async function trackProgress(lessonId: string, seconds: number) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return
  await supabase.from('user_activity_logs').upsert({ 
    user_id: user.id, 
    lesson_id: lessonId, 
    seconds_watched: Math.floor(seconds), 
    last_access: new Date().toISOString() 
  }, { onConflict: 'user_id,lesson_id' })
}

/// --- FAVORITOS / SALVOS ---

export async function toggleProductSave(productId: string, isSaved: boolean) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  console.log(`[ACTION] Tentando ${isSaved ? 'REMOVER' : 'SALVAR'} curso: ${productId}`)

  if (isSaved) {
    // Remover
    const { error } = await supabase
      .from('user_saved_products')
      .delete()
      .eq('user_id', user.id)
      .eq('product_id', productId)
    
    if (error) console.error("Erro ao remover:", error)
    else console.log("Sucesso ao remover!")

  } else {
    // Salvar
    const { error } = await supabase
      .from('user_saved_products')
      .insert({ user_id: user.id, product_id: productId })

    if (error) console.error("Erro ao salvar:", error)
    else console.log("Sucesso ao salvar!")
  }
  
  revalidatePath('/app')
  revalidatePath('/app/saved')
}
// --- PERFIL DO USUÁRIO ---

export async function updateProfile(formData: FormData) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return

  const fullName = formData.get('full_name') as string
  const file = formData.get('avatar') as File
  
  // Mantém a foto antiga se não mandar uma nova
  let avatarUrl = formData.get('current_avatar_url') as string

  console.log("Iniciando atualização de perfil para:", user.email)

  // 1. Se tiver arquivo novo, faz upload
  if (file && file.size > 0) {
    console.log("Encontrou arquivo, fazendo upload...")
    
    // Nome único para evitar cache do navegador (timestamp)
    const fileExt = file.name.split('.').pop()
    const fileName = `${user.id}-${Date.now()}.${fileExt}`

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(fileName, file, { upsert: true })

    if (uploadError) {
      console.error('ERRO NO UPLOAD:', uploadError)
    } else {
      // Pega a URL pública
      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName)
      
      avatarUrl = urlData.publicUrl
      console.log("Upload sucesso. Nova URL:", avatarUrl)
    }
  }

  // 2. Atualiza os dados no banco
  const { error: dbError } = await supabase.from('profiles').upsert({
    id: user.id,
    email: user.email, // Garante que o email fique salvo
    full_name: fullName,
    avatar_url: avatarUrl,
    updated_at: new Date().toISOString()
  })

  if (dbError) {
    console.error("ERRO NO BANCO:", dbError)
  } else {
    console.log("Perfil salvo com sucesso!")
  }

  // 3. FORÇA A ATUALIZAÇÃO DE TUDO
  revalidatePath('/', 'layout') // Atualiza o layout raiz
  revalidatePath('/app', 'layout') // Atualiza o layout do app
  revalidatePath('/app/profile') // Atualiza a página de perfil
}