'use client'

import { useState } from 'react'
import { 
  Plus, Trash2, Edit2, ChevronRight, 
  Video, FileText, Lock, Unlock, MoreVertical, ShoppingCart 
} from 'lucide-react'
import { createProduct, deleteProduct, addModule, deleteModule, addLesson, deleteLesson, toggleProductLock } from './actions'
import EditorModal from './EditorModal'

export default function AdminClient({ products }: { products: any[] }) {
  // Seleciona o primeiro produto por padrão ou null
  const [expandedProduct, setExpandedProduct] = useState<string | null>(products?.[0]?.id || null)
  const [editingItem, setEditingItem] = useState<{ item: any, type: 'product' | 'lesson' } | null>(null)

  // Encontra o produto selecionado na lista para mostrar na direita
  const selectedProductData = products?.find(p => p.id === expandedProduct)

  // Ordena módulos por data
  const sortedModules = selectedProductData?.modules?.sort((a: any, b: any) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start h-full">
      
      {/* --- COLUNA ESQUERDA: LISTA DE CURSOS --- */}
      <div className="lg:col-span-4 space-y-4">
        
        {/* Criar Novo Curso */}
        <div className="flex gap-2">
           <form action={async (fd) => await createProduct(fd.get('title') as string)} className="flex-1 flex gap-2">
              <input name="title" placeholder="Nome do Novo Curso..." className="w-full bg-zinc-900 border border-white/5 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-rose-600 transition" required />
              <button type="submit" className="bg-white text-black p-3 rounded-xl hover:bg-zinc-200 transition"><Plus size={18} /></button>
           </form>
        </div>

        {/* Lista de Cards */}
        <div className="space-y-3 max-h-[600px] overflow-y-auto custom-scrollbar pr-2">
          {products?.map((product) => (
            <div 
              key={product.id}
              onClick={() => setExpandedProduct(product.id)}
              className={`p-5 rounded-2xl border cursor-pointer transition-all relative group flex flex-col gap-4 ${expandedProduct === product.id ? 'bg-zinc-900 border-rose-600/50 shadow-lg shadow-rose-900/10' : 'bg-black border-white/5 hover:border-white/10'}`}
            >
              {/* Topo do Card */}
              <div className="flex justify-between items-start">
                <div>
                  <h3 className={`font-black uppercase italic text-sm ${expandedProduct === product.id ? 'text-white' : 'text-zinc-500'}`}>{product.title}</h3>
                  <p className="text-[10px] font-bold text-zinc-600 mt-1 tracking-wider">{product.modules?.length || 0} MÓDULOS</p>
                </div>
                {/* Botões de Editar/Excluir (Só aparecem se selecionado) */}
                {expandedProduct === product.id && (
                  <div className="flex gap-1">
                    <button onClick={(e) => {e.stopPropagation(); setEditingItem({ item: product, type: 'product' })}} className="p-2 hover:bg-white/10 rounded-lg text-zinc-400 hover:text-white transition"><Edit2 size={14}/></button>
                    <button onClick={async (e) => {e.stopPropagation(); if(confirm('Apagar curso?')) await deleteProduct(product.id)}} className="p-2 hover:bg-red-500/10 rounded-lg text-zinc-600 hover:text-red-500"><Trash2 size={14}/></button>
                  </div>
                )}
              </div>
              
              {/* --- AQUI ESTÁ O CADEADO (STATUS DO CURSO) --- */}
              <div className="border-t border-white/5 pt-3">
                 <button 
                    onClick={(e) => {
                        e.stopPropagation(); // Impede de abrir o curso ao clicar no cadeado
                        toggleProductLock(product.id, product.is_locked_by_default);
                    }} 
                    className={`w-full flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${product.is_locked_by_default ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white' : 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500 hover:text-white'}`}
                 >
                    {product.is_locked_by_default ? (
                        <> <Lock size={12} /> Bloqueado (Venda) </>
                    ) : (
                        <> <Unlock size={12} /> Liberado (Grátis) </>
                    )}
                 </button>
              </div>

            </div>
          ))}
        </div>
      </div>

      {/* --- COLUNA DIREITA: CONTEÚDO DO CURSO (MÓDULOS E AULAS) --- */}
      <div className="lg:col-span-8 bg-[#09090A] border border-white/5 rounded-[32px] p-8 flex flex-col h-full min-h-[600px]">
        {selectedProductData ? (
          <>
            <div className="flex justify-between items-center mb-6 pb-6 border-b border-white/5">
               <div>
                 <div className="flex items-center gap-2 mb-1">
                    <p className="text-[9px] font-black uppercase tracking-[0.2em] text-rose-600">Gerenciando</p>
                    {selectedProductData.is_locked_by_default && <span className="bg-rose-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-full uppercase flex items-center gap-1"><ShoppingCart size={8}/> Produto Pago</span>}
                 </div>
                 <h2 className="text-2xl font-black text-white italic uppercase tracking-tighter">{selectedProductData.title}</h2>
               </div>
               
               <form action={async (fd) => await addModule(selectedProductData.id, fd.get('title') as string)} className="flex gap-2">
                  <input name="title" placeholder="Nome do Módulo..." className="bg-zinc-900 border-none rounded-lg px-4 py-2 text-xs text-white outline-none w-48 focus:ring-1 focus:ring-rose-500/50" required />
                  <button type="submit" className="bg-white/5 hover:bg-white hover:text-black text-white px-4 py-2 rounded-lg text-[10px] font-black uppercase transition">+ Módulo</button>
               </form>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 max-h-[500px] space-y-6">
              {sortedModules?.length === 0 && (
                 <div className="text-center py-20 opacity-30 flex flex-col items-center">
                    <MoreVertical size={40} className="mb-2"/>
                    <p className="text-xs font-black uppercase">Nenhum módulo criado</p>
                 </div>
              )}

              {sortedModules?.map((module: any) => (
                <div key={module.id} className="bg-black/40 border border-white/5 rounded-2xl overflow-hidden">
                  <div className="bg-white/[0.02] p-4 flex justify-between items-center border-b border-white/5">
                    <h4 className="font-bold text-xs text-zinc-300 uppercase tracking-wide flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-rose-600" /> {module.title}
                    </h4>
                    <button onClick={() => { if(confirm('Apagar módulo?')) deleteModule(module.id) }} className="text-zinc-600 hover:text-red-500 transition"><Trash2 size={12}/></button>
                  </div>

                  <div className="p-2 space-y-1">
                    {module.lessons?.sort((a:any, b:any) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()).map((lesson: any) => (
                      <div key={lesson.id} className="group flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition">
                        <div className="flex items-center gap-3">
                          {/* Ícone inteligente: PDF ou Vídeo */}
                          {lesson.type === 'pdf' ? <FileText size={14} className="text-blue-500" /> : <Video size={14} className="text-rose-600" />}
                          <span className="text-xs font-bold text-zinc-400 group-hover:text-white transition">{lesson.title}</span>
                        </div>
                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition">
                          <button onClick={() => setEditingItem({ item: lesson, type: 'lesson' })} className="text-zinc-500 hover:text-white"><Edit2 size={12}/></button>
                          <button onClick={() => deleteLesson(lesson.id)} className="text-zinc-500 hover:text-red-500"><Trash2 size={12}/></button>
                        </div>
                      </div>
                    ))}
                    
                    <form action={async (fd) => await addLesson(module.id, fd.get('title') as string, 'video')} className="mt-2 flex gap-2 px-2 py-2">
                      <input name="title" placeholder="Adicionar Aula..." className="flex-1 bg-transparent text-xs text-zinc-600 outline-none focus:text-white transition" required />
                      <button type="submit" className="text-[9px] font-black uppercase text-zinc-700 hover:text-white transition">+ Add</button>
                    </form>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center text-zinc-600 text-xs font-bold uppercase tracking-widest">
            Selecione um curso para gerenciar
          </div>
        )}
      </div>

      {/* MODAL DE EDIÇÃO */}
      {editingItem && (
        <EditorModal 
          item={editingItem.item} 
          type={editingItem.type} 
          onClose={() => setEditingItem(null)} 
        />
      )}
    </div>
  )
}