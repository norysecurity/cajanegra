'use client'
import { LogOut } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function SignOutButton() {
  const router = useRouter()
  const supabase = createClient()

  const handleSignOut = async () => {
    // 1. Desloga no Supabase (limpa sessão no browser)
    await supabase.auth.signOut()
    
    // 2. Chama nossa rota de limpeza no servidor (pra garantir)
    await fetch('/auth/signout', { method: 'POST' })

    // 3. Força o redirecionamento para o login
    router.push('/auth/login')
    router.refresh() // Atualiza a página pra limpar cache
  }

  return (
    <button 
      onClick={handleSignOut}
      className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-red-500 hover:bg-red-900/10 transition border border-transparent hover:border-red-900/20"
      title="Sair do App"
    >
      <LogOut size={18} />
    </button>
  )
}