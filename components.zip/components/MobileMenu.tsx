'use client'

import Link from 'next/link'
import { useRouter, usePathname } from 'next/navigation'
import { LogOut, Search, User, Play, Heart } from 'lucide-react'
import { createClient } from '@/lib/supabase/client' // Importamos o arquivo do Passo 1

export default function MobileMenu() {
  const router = useRouter()
  const pathname = usePathname()
  const supabase = createClient()

  // Função para deslogar
  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.refresh()
    router.push('/auth/login') // Manda de volta pro login
  }

  // Função para saber se o link está ativo
  const isActive = (path: string) => pathname === path

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0F0F10] border-t border-white/10 pb-safe pt-2 px-6">
      <div className="flex justify-between items-center h-16">
        
        {/* 1. SAIR (LOGOUT) - SUBSTITUI O INÍCIO */}
        <button 
          onClick={handleLogout}
          className="flex flex-col items-center gap-1 text-red-600 hover:text-red-400 transition"
        >
          <LogOut size={22} strokeWidth={2} />
          <span className="text-[10px] font-bold">Sair</span>
        </button>

        {/* 2. BUSCA */}
        <Link href="#" className="flex flex-col items-center gap-1 text-zinc-500 hover:text-white">
          <Search size={22} />
          <span className="text-[10px] font-medium">Buscar</span>
        </Link>

        {/* 3. CENTRAL - AULAS */}
        <Link href="/app" className="relative -top-6 group">
           <div className="w-16 h-16 bg-rose-600 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(225,29,72,0.6)] border-[6px] border-[#0F0F10] transition-transform active:scale-95">
              <Play size={28} className="text-white ml-1" fill="white" />
           </div>
           <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-black uppercase text-zinc-400 tracking-widest group-active:text-rose-500">
              Aulas
           </span>
        </Link>

        {/* 4. SALVOS - AGORA COM LINK CERTO */}
        <Link 
          href="/app/saved" 
          className={`flex flex-col items-center gap-1 ${isActive('/app/saved') ? 'text-rose-500' : 'text-zinc-500 hover:text-white'}`}
        >
          <Heart size={22} fill={isActive('/app/saved') ? "currentColor" : "none"} />
          <span className="text-[10px] font-medium">Salvos</span>
        </Link>

        {/* 5. PERFIL */}
        <Link href="/app/profile" className={`flex flex-col items-center gap-1 ${isActive('/app/profile') ? 'text-rose-500' : 'text-zinc-500 hover:text-white'}`}>
          <User size={22} strokeWidth={isActive('/app/profile') ? 3 : 2} />
          <span className="text-[10px] font-medium">Perfil</span>
        </Link>

      </div>
    </div>
  )
}