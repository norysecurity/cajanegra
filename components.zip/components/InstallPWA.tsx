'use client'

import { useEffect, useState } from 'react'
import { Download, X } from 'lucide-react'

export default function InstallPWA() {
  const [supportsPWA, setSupportsPWA] = useState(false)
  const [promptInstall, setPromptInstall] = useState<any>(null)
  const [isInstalled, setIsInstalled] = useState(false)

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault()
      setSupportsPWA(true)
      setPromptInstall(e)
    }
    
    // Ouve o evento do navegador que diz "Pode instalar!"
    window.addEventListener('beforeinstallprompt', handler)
    
    // Verifica se já está rodando como APP
    if (window.matchMedia('(display-mode: standalone)').matches) {
        setIsInstalled(true);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler)
  }, [])

  const handleInstallClick = (e: any) => {
    e.preventDefault()
    if (!promptInstall) {
      return
    }
    promptInstall.prompt()
  }

  // Se já estiver instalado ou o navegador não suportar, não mostra nada
  if (!supportsPWA || isInstalled) {
    return null 
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-[100] animate-in fade-in slide-in-from-bottom-4">
      <div className="bg-[#161618] border border-white/10 rounded-2xl p-4 shadow-2xl flex items-center justify-between">
        <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center">
                <Download className="text-white" size={20} />
            </div>
            <div>
                <h4 className="text-white font-bold text-sm">Instalar Aplicativo</h4>
                <p className="text-zinc-400 text-xs">Acesse mais rápido sem barras.</p>
            </div>
        </div>
        <div className="flex items-center gap-2">
            <button 
                onClick={() => setSupportsPWA(false)}
                className="p-2 text-zinc-500 hover:text-white"
            >
                <X size={20} />
            </button>
            <button 
                onClick={handleInstallClick}
                className="bg-white text-black px-4 py-2 rounded-lg text-xs font-black uppercase hover:bg-zinc-200 transition"
            >
                Instalar
            </button>
        </div>
      </div>
    </div>
  )
}