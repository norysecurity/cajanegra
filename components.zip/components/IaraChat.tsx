'use client'

import { useState, useRef, useEffect } from 'react'
import { MessageCircle, X, Send, Sparkles } from 'lucide-react'
import { useChat } from '@ai-sdk/react' // ✅ CORRETO PRA SUA VERSÃO

export default function IaraChat() {
  const [isOpen, setIsOpen] = useState(false)
  const [input, setInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const { messages, sendMessage, isLoading } = useChat({
    api: '/api/chat',
    onResponse: () => console.log('Iara respondendo...'),
    onError: () => alert('Erro ao conectar com a Iara.')
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    await sendMessage({ content: input })
    setInput('')
  }

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  return (
    <div className="fixed bottom-24 right-4 z-50 md:bottom-8 md:right-8">
      {isOpen && (
        <div className="mb-4 w-[90vw] md:w-[400px] h-[500px] bg-[#0F0F10] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">

          {/* Header */}
          <div className="bg-gradient-to-r from-rose-600 to-rose-800 p-4 flex justify-between items-center text-white font-bold">
            <div className="flex items-center gap-2"><span>🧜‍♀️</span> Iara AI</div>
            <button onClick={() => setIsOpen(false)}><X size={20} /></button>
          </div>

          {/* Mensagens */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-zinc-900/50">
            {messages.length === 0 && (
              <div className="text-center text-zinc-500 mt-20">
                <Sparkles className="mx-auto opacity-20 mb-2" />
                <p className="text-sm">Como posso te ajudar hoje?</p>
              </div>
            )}

            {messages.map((m) => (
              <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm ${
                  m.role === 'user'
                    ? 'bg-rose-600 text-white'
                    : 'bg-zinc-800 text-zinc-200 border border-white/5'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-3 bg-zinc-900 border-t border-white/5 flex gap-2">
            <input
              className="flex-1 bg-zinc-800 text-white text-sm rounded-full px-4 border border-white/5 outline-none focus:border-rose-500"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pergunte algo..."
            />
            <button
              type="submit"
              disabled={isLoading || !input}
              className="bg-rose-600 text-white p-2.5 rounded-full disabled:opacity-30"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      )}

      {!isOpen && (
        <button onClick={() => setIsOpen(true)} className="w-14 h-14 bg-rose-600 rounded-full shadow-lg flex items-center justify-center">
          <MessageCircle size={28} className="text-white fill-white" />
        </button>
      )}
    </div>
  )
}
